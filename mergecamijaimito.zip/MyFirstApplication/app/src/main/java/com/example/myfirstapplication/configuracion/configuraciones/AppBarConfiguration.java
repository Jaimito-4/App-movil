package com.example.myfirstapplication.configuracion.configuraciones;

public class AppBarConfiguration {
}
