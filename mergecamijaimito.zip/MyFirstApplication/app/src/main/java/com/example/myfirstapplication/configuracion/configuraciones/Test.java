package com.example.myfirstapplication.configuracion.configuraciones;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Test extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityTestBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}