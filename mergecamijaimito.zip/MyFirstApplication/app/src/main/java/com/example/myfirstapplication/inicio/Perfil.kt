package com.example.myfirstapplication

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Perfil: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perfil)
    }
}