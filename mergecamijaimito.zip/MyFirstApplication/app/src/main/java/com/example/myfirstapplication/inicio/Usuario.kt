package com.example.myfirstapplication.inicio

data class Usuario(val nombre: String, val contrasena: String)
